package com.programming.techie.notificationservice;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.listener.ListenerContainerConsumerFailedEvent;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.Message;

import java.util.function.Consumer;

@SpringBootApplication
@EnableEurekaClient
public class NotificationServiceApplication {
	
	@Autowired
	private QueueConsumer admin;

    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
    }
    
    
	/*
	 * @GetMapping("/getQueueMesgs") public void getQuesMessage() {
	 * 
	 * }
	 */
    
	/*
	 * @Bean public ApplicationRunner runner(CachingConnectionFactory cf) {
	 * cf.getRabbitConnectionFactory().setAutomaticRecoveryEnabled(false); return
	 * args -> { }; }
	 * 
	 * @EventListener public void events(ListenerContainerConsumerFailedEvent event)
	 * { SimpleMessageListenerContainer container = (SimpleMessageListenerContainer)
	 * event.getSource(); String queueName = container.getQueueNames()[0]; if
	 * (queueName.startsWith("springCloudBus")) { this.admin.declareQueue(new
	 * Queue(queueName, false, true, true, null)); } }
	 */
	/*
	 * @Bean public Consumer<Message<String>> notificationEventSupplier() { return
	 * message -> new EmailSender().sendEmail(message.getPayload()); }
	 */
}
