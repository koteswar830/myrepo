package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.EurekaclientApplication;
import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RestController
@RequestMapping("productApi")
public class ProductController {
	
	@Autowired
	private ProductService productService;

	public static void main(String[] args) {
		SpringApplication.run(EurekaclientApplication.class, args);
	}
	
	@GetMapping("/")
	public String init2()
	{
		return "clien";
	}
	
	@GetMapping("/client1")
	public String init1()
	{
		return "client1";
	}
	
	@GetMapping("/client")
	@HystrixCommand(fallbackMethod="fallbackRetrieveConfigurations") 
	public String init()
	{
		//System.out.println(10/0);
		return "client1";
	}
	
	public String fallbackRetrieveConfigurations()  
	{  
	//returning the default configuration     
	return "called fall back method";
	}  
	
	@PostMapping("/saveProd")
	public Product saveProduct(@RequestBody Product prod)
	{
		return productService.saveProduct(prod);
	}
	//@GetMapping("/clientser/getProd/{productId}")
	@GetMapping("/{id}")
	public Product getProduct(@PathVariable Integer id)
	{
		return productService.getProduct(id).get();
	}
	
	
	@GetMapping("/getAllProd")
	public List<Product> getProdduct()
	{
		return productService.getAllProducts();
	}
	
	


}
