package com.example.demo.controller;

import java.util.Random;

import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.messaging.support.MessageBuilder;


import com.example.demo.AuthRequest;
import com.example.demo.DateUtil;
import com.example.demo.Eurekaclient2Application;
import com.example.demo.config.QueueProducer;
import com.example.demo.entity.Customer;
import com.example.demo.entity.Order;
import com.example.demo.entity.OrderDTO;
import com.example.demo.entity.ResponseOrderDTO;
import com.example.demo.service.CustomerService;
import com.example.demo.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.cloud.stream.function.StreamBridge;

@RestController
@RequestMapping("OrderApi")
public class OrderController {
	
    private final StreamBridge streamBridge;
    
    
  

    
    public OrderController(StreamBridge streamBridge) {
        this.streamBridge = streamBridge;
     
    }


	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private QueueProducer queueProducer;
	
	

	public static void main(String[] args) {
		SpringApplication.run(Eurekaclient2Application.class, args);
	}
	
	@GetMapping("client2")
	public String init(@RequestBody AuthRequest authenticationRequest)
	{
		return "client2"+authenticationRequest.getUserName();
	}
	
	@GetMapping("client21")
	public String init()
	{
		return "client2";
	}
	

	
	 @Cacheable(value="Invoice", key="#p0")
	  @GetMapping(value = "/getOrder/{orderId}")
	    public Order getOrderDetails(@PathVariable int orderId) {

	        return orderService.getOrderDetail(orderId);
	       // return ResponseEntity.ok(order);
	    }


	    @PostMapping("/placeOrder")
	    public ResponseOrderDTO placeOrder(@RequestBody OrderDTO orderDTO) throws Exception {
	        //logger.info("Request Payload " + orderDTO.toString());
	        ResponseOrderDTO responseOrderDTO = new ResponseOrderDTO();
	        float amount = orderService.getCartAmount(orderDTO.getCartItems());

	        Customer customer = new Customer(orderDTO.getCustomerName(), orderDTO.getCustomerEmail());
	        Integer customerIdFromDb = customerService.isCustomerPresent(customer);
	        if (customerIdFromDb != null) {
	            customer.setId(customerIdFromDb);
	           // logger.info("Customer already present in db with id : " + customerIdFromDb);
	        }else{
	            customer = customerService.saveCustomer(customer);
	          //  logger.info("Customer saved.. with id : " + customer.getId());
	        }
	        Order order = new Order(orderDTO.getOrderDescription(), customer, orderDTO.getCartItems());
	        order.setId(2);
	        order = orderService.saveOrder(order);
	        
	        System.out.println("order Id() is"+order.getId());
	      
	       queueProducer.produce(order);
	        
	      //  customerService.saveOrderRabit(order);
	        
	       
           // streamBridge.send("notificationEventSupplier-out-0", MessageBuilder.withPayload(order.getId()).build());

	       // logger.info("Order processed successfully..");

	        responseOrderDTO.setAmount(amount);
	        responseOrderDTO.setDate(DateUtil.getCurrentDateTime());
	        responseOrderDTO.setInvoiceNumber(new Random().nextInt(1000));
	        responseOrderDTO.setOrderId(order.getId());
	        responseOrderDTO.setOrderDescription(orderDTO.getOrderDescription());

	       // logger.info("test push..");

	        return responseOrderDTO;
	    }



}
