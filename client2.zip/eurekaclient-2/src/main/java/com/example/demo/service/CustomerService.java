package com.example.demo.service;


import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.entity.Order;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerService {
	
	
	/*
	 * final RabbitTemplate rabbitTemplate; final Exchange eventExchange;
	 * 
	 * public CustomerService(RabbitTemplate rabbitTemplate,Exchange eventExchange)
	 * { this.rabbitTemplate=rabbitTemplate; this.eventExchange=eventExchange; }
	 * 
	 * public void saveOrderRabit(Order order) {
	 * rabbitTemplate.convertAndSend("messagequeue-exchange", "customer.created",
	 * "customer created"); }
	 */

	
	@Autowired
    private CustomerRepository customerRepository;

	
	

    public Customer saveCustomer(Customer customer){
        return customerRepository.save(customer);
    }

    public Integer isCustomerPresent(Customer customer){
        Customer customer1 = customerRepository.getCustomerByEmailAndName(customer.getEmail(),customer.getName());
        return customer1!=null ? customer1.getId(): null ;
    }
}
