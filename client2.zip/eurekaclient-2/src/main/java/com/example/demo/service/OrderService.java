package com.example.demo.service;


import com.example.demo.dto.Product;
import com.example.demo.entity.Order;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.OrderRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
	
	 @Autowired
	    private RestTemplate restTemplate;
	@Autowired
    private OrderRepository orderRepository;
	
	
    public Order getOrderDetail(int orderId) {
    	System.out.println("gettind data from db");
        Optional<Order> order = this.orderRepository.findById(orderId);
        return order.isPresent() ? order.get() : null;
    }

    public float getCartAmount(List<ShoppingCart> shoppingCartList) {

        float totalCartAmount = 0f;
        float singleCartAmount = 0f;
        int availableQuantity = 0;
        
        


        for (ShoppingCart cart : shoppingCartList) {

            int productId = cart.getProductId();
            
           // Department dept= restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+user.getDepartmentId(),
                  //   Department.class);
            
           // String prodgetUrl="http://client1/clientser/getProd/"+productId;
            
            Product prod=restTemplate.getForObject("http://PRODUCT-SERVICE/productApi/"+productId,Product.class);
System.out.println("after call"+prod.getId());
         //   Optional<Product> product = productRepository.findById(productId);
            if (null !=prod) {
                if (prod.getAvailableQuantity() < cart.getQuantity()) {
                    singleCartAmount = prod.getPrice() * prod.getAvailableQuantity();
                    cart.setQuantity(prod.getAvailableQuantity());
                } else {
                    singleCartAmount = cart.getQuantity() * prod.getPrice();
                    availableQuantity = prod.getAvailableQuantity() - cart.getQuantity();
                }
                totalCartAmount = totalCartAmount + singleCartAmount;
                prod.setAvailableQuantity(availableQuantity);
                availableQuantity=0;
                cart.setProductName(prod.getName());
                cart.setAmount(singleCartAmount);
                
                HttpHeaders headers = new HttpHeaders();
                
            	HttpEntity<Product> httpEntity = new HttpEntity<>(prod, headers);

                
				/*
				 * HttpHeaders headers = new HttpHeaders(); HttpEntity<?> request = new
				 * HttpEntity<>(prod, headers);
				 */
              //  String prodSaveUrl = "http://localhost:9090/client1/saveProduct";
                
                Product prod1 =restTemplate.postForObject("http://PRODUCT-SERVICE/productApi/saveProd",httpEntity,Product.class);
                System.out.println(prod1);
            }
        }
        return totalCartAmount;
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }
}
