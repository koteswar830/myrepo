package com.example.demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.AuthenticationStatus;
import com.example.demo.model.ErrorResponseDto;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtTokenUtil;

@SpringBootApplication
@EnableEurekaClient
@RestController
public class CloudgatewayApplication {

	@Autowired
	private final JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserRepository userRepository;

	

	//@Autowired
	//private CustomUserDetailsService customUserDetailsService;

	public CloudgatewayApplication(JwtTokenUtil jwtTokenUtil) {
		this.jwtTokenUtil = jwtTokenUtil;
	}

	// @Autowired
	// private JwtUtil jwtUtil;

	public static void main(String[] args) {
		SpringApplication.run(CloudgatewayApplication.class, args);
	}

	@PostConstruct
	public void initUsers() {
		List<User> users = Stream.of(new User(101, "javatechie", "password", "javatechie@gmail.com"),
				new User(102, "user1", "pwd1", "user1@gmail.com"), new User(103, "user2", "pwd2", "user2@gmail.com"),
				new User(104, "user3", "pwd3", "user3@gmail.com")).collect(Collectors.toList());
		userRepository.saveAll(users);
	}

	@PostMapping("/authenticate")
	public String createAuthenticationToken(@RequestBody AuthRequest authenticationRequest) throws Exception {
		AuthenticationStatus status = authenticate(authenticationRequest.getUserName(),
				authenticationRequest.getPassword());

		if (!status.getIsAuthenticated()) {
			List<String> details = new ArrayList<>();
			details.add(status.getMessage());
			ErrorResponseDto error = new ErrorResponseDto(new Date(), HttpStatus.UNAUTHORIZED.value(), "UNAUTHORIZED", details, "uri");
			//return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
			return "unauthorised acces";
		}
		/*
		 * if (!status.getIsAuthenticated()) { List<String> details = new ArrayList<>();
		 * details.add(status.getMessage()); ErrorResponseDto error = new
		 * ErrorResponseDto(new Date(), HttpStatus.UNAUTHORIZED.value(), "UNAUTHORIZED",
		 * details, "uri"); //return new ResponseEntity<>(error,
		 * HttpStatus.UNAUTHORIZED); }
		 */

		final String token = jwtTokenUtil.generateToken(authenticationRequest.getUserName());
		return token; 

	}

	private AuthenticationStatus authenticate(String username, String password) {
		AuthenticationStatus status;
		System.out.println("username" + username);
		System.out.println("password" + password);
		User user = userRepository.findByUserName(username);

		if ((!username.equals(user.getUserName())) || (!password.equals(user.getPassword()))) {
			status = new AuthenticationStatus(false, "Invalid Username/Password");
		} else {
			status = new AuthenticationStatus(true, "Authentication Successful");
		}

		return status;
	}
}
